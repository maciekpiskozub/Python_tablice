import sys

from PyQt6.QtWidgets import QApplication, QWidget, QMessageBox


class PomocnikMatematyczny(QWidget):
    def __init__(self):
        super().__init__()
        self.show()

    def poleTrojkata(self):
        try:
            a = float(self.aEdit.text())
            b = float(self.aEdit.text())
            c = float(self.aEdit.text())

            if a + b > c and a + c > b and b+ c > a:
                s = (a+b+c)/2
                pole = (s * (s-a) * (s-b) * (s-c)) ** 0.5
                self.resultEdit.setText(str(pole))
            else:
                QMessageBox.warning(self,'Błąd', 'To nie jest trójkąt')
        except ValueError:
                QMessageBox.warning(self, 'Błąd', 'Wprowadz poprawne liczby')
                self.resultEdit.setText('')

    def rownanieLiniowe(self):
        try:
            a = float(self.aEdit.text())
            b = float(self.aEdit.text())

            if a == 0:
                QMessageBox.warning(self, 'Błąd', 'Sprzeczność!')
                self.resultEdit.setText('')
            else:
                wynik = -b / a
                self.resultEdit.setText(str(wynik))
        except ValueError:
            QMessageBox.warning(self, 'Błąd', 'Wprowadz poprawne liczby')
            self.resultEdit.setText('')


    def okno(self):
        wybor = self.comboBox.currentText()

        if wybor == "Równanie liniowe":
            self.rownanieLiniowe()
        elif wybor == "Pole trójkąta":
            self.poleTrojkata()

    def otwieranieOkna(self):
        self.konfiguj.clicked.connect(self.poleTrojkata())



if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = PomocnikMatematyczny()
    ex.show()
    sys.exit(app.exec())
