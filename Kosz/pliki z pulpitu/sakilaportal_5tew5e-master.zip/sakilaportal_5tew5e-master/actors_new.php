<?php
// Czy w ogóle przesłano formularz?
if(!(isset($_POST['first_name']) && isset($_POST['last_name']))) {
    header('Location: actors.php');
    exit(1);
}

// Pobranie danych z formularza
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];

// Połączenie z bazą
require_once('db.php');
$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBDATABASE);

// INSERT INTO
// WARNING: SQL Injection ahead
$r = mysqli_query($conn, "INSERT INTO actor (first_name, last_name) VALUES ('$first_name', '$last_name')");

// Sprawdzenie, czy się dodało
if(mysqli_affected_rows($conn) != 1) {
    echo "Błąd dodawania aktora";
    exit(2);
}

// Pobranie ID nowo dodanego rekordu
$actor_id = mysqli_insert_id($conn);

// Rozłączenie z bazą
mysqli_close($conn);

// Przekierowanie na stronę nowo dodanego aktora
header("Location: actor.php?id=$actor_id");