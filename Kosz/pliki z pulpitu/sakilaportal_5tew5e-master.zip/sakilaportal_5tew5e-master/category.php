<?php

/*
0. Pobranie ID z $_GET
1. Połączenie z bazą
2. Wysłanie zapytania: informacja o kategorii (id, nazwa, liczba filmów w tej kategorii)
3. Pobranie rezultatów zapytania
4. Wysłanie zapytanie: lista filmów w tej kategorii (id filmu, tytuł)
5. Pobranie rezultatów zapytania
6. Zakończenie połączenia z bazą

*/

// 0. Pobranie ID z $_GET
// 0a. Sprawdzenie, czy podano ID w żądaniu - jeśli nie, to przekieruj na stronę index.php
if (!isset($_GET['id'])) {
    // echo "Nie podano ID";
    // exit(1);
    header('Location: index.php');
    exit(1);
}

// 0b. Pobranie ID do zmiennej $category_id
$category_id = $_GET['id'];


// 1. Połączenie z bazą
require_once('db.php');
$conn = new mysqli(DBHOST, DBUSER, DBPASS, DBDATABASE);


// 2. Wysłanie zapytania: informacja o kategorii (id, nazwa, liczba filmów w tej kategorii)
$q = "SELECT category.category_id, category.name, COUNT(film_category.film_id) AS film_count FROM category JOIN film_category ON category.category_id = film_category.category_id WHERE category.category_id = '$category_id'";
$r = $conn->query($q); // proceduralnie: mysqli_query($conn, $q)

// 2a. Sprawdzenie, czy nie przyszedł dokładnie 1 rekord
if ($r->num_rows != 1) { // proceduralnie: if(mysqli_num_rows($r) != 1)
    header('Location: index.php');
    exit(2);
}

// 3. Pobranie rezultatów zapytania
$category = $r->fetch_assoc();


// 4. Wysłanie zapytanie: lista filmów w tej kategorii (id filmu, tytuł)
$r = $conn->query("SELECT film.film_id, film.title FROM film JOIN film_category USING(film_id) WHERE film_category.category_id = '$category_id'");


// 5. Pobranie rezultatów zapytania
$films = $r->fetch_all(MYSQLI_ASSOC); // proceduralnie: 
//                                       mysqli_fetch_all($r, MYSQLI_ASSOC);


// 6. Zakończenie połączenia z bazą
$conn->close(); // proceduralnie: mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $category['name'] ?> | Sakila</title>
</head>

<body>
    <h1><?= $category['name'] ?></h1>
    <p>Liczba filmów w tej kategorii: <?= $category['film_count'] ?></p>

    <h3>Lista filmów</h3>
    <ol>
        <?php
        foreach ($films as $film) {
            echo "<li><a href='film.php?id=$film[film_id]'>$film[title]</a></li>";
        }
        ?>
    </ol>
</body>

</html>