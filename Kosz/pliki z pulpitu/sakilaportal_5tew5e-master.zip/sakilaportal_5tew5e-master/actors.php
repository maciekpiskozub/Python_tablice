<?php
require_once('db.php');

$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBDATABASE);

$q = "SELECT actor_id, first_name, last_name FROM actor";
$r = mysqli_query($conn, $q);

$actors = mysqli_fetch_all($r, MYSQLI_ASSOC);
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista aktorów | Sakila</title>
</head>

<body>
    <h3>Dodawanie nowego aktora</h3>
    <form action="actors_new.php" method="post">
        <div>
            <label for="first_name">Imię: </label>
            <input type="text" name="first_name" id="first_name" required>
        </div>
        <div>
            <label for="last_name">Nazwisko: </label>
            <input type="text" name="last_name" id="last_name" required>
        </div>
        <div>
            <button type="submit">Dodaj</button>
        </div>
    </form>
    <h3>Lista aktorów</h3>
    <ol>
        <?php
        foreach ($actors as $a) {
            echo "<li><a href='actor.php?id=$a[actor_id]'>$a[first_name] $a[last_name]</a></li>";
        }
        ?>
    </ol>
</body>

</html>