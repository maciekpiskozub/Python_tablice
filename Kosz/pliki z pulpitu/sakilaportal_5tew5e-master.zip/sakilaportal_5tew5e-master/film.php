<?php
require_once('db.php');
$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBDATABASE);

$film_id = $_GET['id'];
$q = "SELECT title, description, length FROM film WHERE film_id = '$film_id'";
$r = mysqli_query($conn, $q);

if (mysqli_num_rows($r) != 1) {
    mysqli_close($conn);
    header('Location: index.php');
    exit();
}

$film = mysqli_fetch_assoc($r);

// Pobranie kategorii, do których przypisano film
$q2 = "SELECT category.category_id, category.name FROM film_category JOIN category USING(category_id) WHERE film_category.film_id = '$film_id'";
$r2 = mysqli_query($conn, $q2);
$categories = mysqli_fetch_all($r2, MYSQLI_ASSOC);

// Pobranie kategorii, do których nie przypisano filmu
$q3 = "SELECT c.category_id, c.name FROM category AS c WHERE c.category_id NOT IN (SELECT category_id FROM film_category WHERE film_id = '$film_id')";
$r3 = mysqli_query($conn, $q3);
$categories_new = mysqli_fetch_all($r3, MYSQLI_ASSOC);

// Pobranie obsady filmu
$q = "SELECT actor.actor_id, actor.first_name, actor.last_name FROM actor, film_actor WHERE actor.actor_id = film_actor.actor_id AND film_id = '$film_id'";
$r = mysqli_query($conn, $q);
?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $film['title'] ?> | Sakila</title>
</head>

<body>
    <h1><?php echo $film['title'] ?></h1>
    <p><?php echo $film['description'] ?></p>
    <p>Czas trwania: <?php echo $film['length'] ?> minut</p>
    <p>Kategorie: <?php
                    foreach ($categories as $c) {
                        echo "<a href='category.php?id=$c[category_id]'>$c[name]</a>, ";
                    }
                    ?></p>

    <h3>Ustawianie kategorii</h3>
    <form action="film_set_category.php" method="post">
        <div class="row" style="display: flex">
            <div>
                <p>Dostępne kategorie</p>
                <select name="categories" id="categories" multiple size="20">
                <?php
                foreach($categories_new as $c) {
                    echo "<option value='$c[category_id]'>$c[name]</option>";
                }
                ?>
                </select>
            </div>
            <div>
                <input type="submit" name="add_new_categories" value="Dodaj >">
                <br>
                <input type="submit" name="remove_categories" value="< Usuń">
            </div>
            <div>
                <p>Wybrane kategorie</p>
                <select name="categories_added" id="categories_added" multiple size="20">
                    <?php
                    foreach ($categories as $c) {
                        echo "<option value='$c[category_id]'>$c[name]</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
    </form>

    <h3>Obsada</h3>
    <table>
        <thead> <!-- Nagłówek tabeli -->
            <tr> <!-- TABLE ROW - wiersz tabeli -->
                <th>ID</th> <!-- TABLE HEADER - nagłówek (komórka nagłówka) -->
                <th>Imię</th>
                <th>Nazwisko</th>
            </tr>
        </thead>
        <tbody> <!-- Ciało tabeli - część z danymi -->
            <?php while ($row = mysqli_fetch_assoc($r)) {
                echo "<tr>";
                echo "  <th scope='row'>$row[actor_id]</th>";
                echo "  <td>$row[first_name]</td>";
                echo "  <td><a href='actor.php?id=$row[actor_id]'>$row[last_name]</a></td>";
                echo "</tr>";
            }
            ?>
            <!-- <tr>  -->
            <!-- <th scope="row">1</th> nagłówek wiersza -->
            <!-- <td>Imię aktora</td> TABLE DATA - dane tabeli -->
            <!-- <td>Nazwisko aktora</td> -->
            <!-- </tr> -->
        </tbody>
    </table>
</body>

</html>

<?php
mysqli_close($conn);
?>