<?php
// Czy w ogóle przesłano formularz?
if(!isset($_POST['name'])) {
    header('Location: categories.php');
    exit(1);
}

// Pobranie danych z formularza
$name = $_POST['name'];

// Połączenie z bazą
require_once('db.php');
$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBDATABASE);

// INSERT INTO
// WARNING: SQL Injection ahead
$r = mysqli_query($conn, "INSERT INTO category (name) VALUES ('$name')");

// Sprawdzenie, czy się dodało
if(mysqli_affected_rows($conn) != 1) {
    echo "Błąd dodawania kategorii";
    exit(2);
}

// Pobranie ID nowo dodanego rekordu
$category_id = mysqli_insert_id($conn);

// Rozłączenie z bazą
mysqli_close($conn);

// Przekierowanie na stronę nowo dodanej kategorii
header("Location: category.php?id=$category_id");