<?php
require_once('db.php');

$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBDATABASE);

$q = "SELECT category_id, name FROM category";
$r = mysqli_query($conn, $q);

$categories = mysqli_fetch_all($r, MYSQLI_ASSOC);
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista kategorii | Sakila</title>
</head>

<body>
    <h3>Dodawanie nowej kategorii</h3>
    <form action="categories_new.php" method="post">
        <div>
            <label for="name">Nazwa: </label>
            <input type="text" name="name" id="name" required>
        </div>
        <div>
            <button type="submit">Dodaj</button>
        </div>
    </form>
    <h3>Lista kategorii</h3>
    <ol>
        <?php
        foreach ($categories as $c) {
            echo "<li><a href='category.php?id=$c[category_id]'>$c[name]</a></li>";
        }
        ?>
    </ol>
</body>

</html>