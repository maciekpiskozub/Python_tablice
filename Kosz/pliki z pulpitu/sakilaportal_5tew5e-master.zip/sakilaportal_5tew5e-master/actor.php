<?php
require_once('db.php');
$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBDATABASE);

// pobranie ID, imienia i nazwiska aktora
// o ID podanym w $_GET['id']
$actor_id = $_GET['id'];
$q = "SELECT actor_id, first_name, last_name FROM actor WHERE actor_id = '$actor_id'";
$r = mysqli_query($conn, $q);

$actor = mysqli_fetch_assoc($r);

// pobierz id i tytuły filmów, w których grał aktor o zadanym ID
$q = "SELECT film.film_id, film.title FROM film JOIN film_actor ON film.film_id = film_actor.film_id WHERE film_actor.actor_id = '$actor_id'";
$r = mysqli_query($conn, $q);

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $actor['first_name'] ?> <?= $actor['last_name'] ?> | Sakila</title>
</head>
<body>
    <h1><?= $actor['first_name'] ?> <?= $actor['last_name'] ?></h1>
    <!-- równoważnie: -->
    <h1><?php echo $actor['first_name'] ?> <?php echo $actor['last_name'] ?></h1>

    <p>Filmy z udziałem <?= $actor['first_name'] ?> <?= $actor['last_name'] ?>:</p>
    <ol>
        <?php
        while($row = mysqli_fetch_assoc($r)) {
            echo "<li><a href='film.php?id=$row[film_id]'>$row[title]</a></li>";
        }
        ?>
    </ol>
</body>
</html>

<?php 
mysqli_close($conn);
?>