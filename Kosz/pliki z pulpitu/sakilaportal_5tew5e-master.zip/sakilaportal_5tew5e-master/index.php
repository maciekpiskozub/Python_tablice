<?php
require_once('db.php');

$conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBDATABASE);

$q = "SELECT film_id, title FROM film";
$r = mysqli_query($conn, $q);

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista filmów | Sakila</title>
</head>
<body>
    <h2>Lista filmów</h2>
    <ol>
        <?php 
            while($row = mysqli_fetch_array($r)) {
                echo "<li><a href='film.php?id=$row[film_id]'>$row[title]</a></li>";
            }
        ?>
    </ol>
</body>
</html>

<?php
mysqli_close($conn);
?>