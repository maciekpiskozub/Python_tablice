function generuj(){
    let numer = document.getElementById('numer').value;
    document.getElementById('kg').style.backgroundColor=`hsl(${numer}, 100%,50%)`;
    document.getElementById('k2').style.backgroundColor=`hsl(${numer}, 80%,50%)`;
    document.getElementById('k3').style.backgroundColor=`hsl(${numer}, 60%,50%)`;
    document.getElementById('k4').style.backgroundColor=`hsl(${numer}, 40%,50%)`;
    document.getElementById('k5').style.backgroundColor=`hsl(${numer}, 20%,50%)`;
}